using IniParser.Model;
using IniParser;
using Masuit.Tools.Files;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.Mvc;
using Mirai.Net.Data.Messages.Receivers;
using Mirai.Net.Sessions;
using Newtonsoft.Json.Linq;
using System.Reactive.Linq;
using static System.Collections.Specialized.BitVector32;
using System.Drawing;
using System.Linq.Expressions;
using Manganese.Array;
using Mirai.Net.Sessions.Http.Managers;
using SixLabors.ImageSharp.Drawing;
using System.Text.Unicode;
using System.Text;
using System.IO;
using SimpleExcel;
using asg_form.Controllers;
using MiniExcelLibs;
using Masuit.Tools;
using Microsoft.AspNetCore.Http;
using Castle.Components.DictionaryAdapter.Xml;

namespace asg_form.Controllers
{
  

    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };
      

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

    }

   // [Route("api/updateform/")]
    public class �ύ���� : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        public static void WriteFile(String str)
        {
            StreamWriter sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "/allteam.txt", true, System.Text.Encoding.Default);
            sw.WriteLine(str);
            sw.Close();
        }

        [Route("api/like/")]
        [HttpPost]
        public async Task<ActionResult<like>> Post(string name)
        {
        
        using TestDbContext ctx=new TestDbContext();
            var b=ctx.Forms.Single(b=>b.team_name== name);
           b.piaoshu = b.piaoshu+1;
            await ctx.SaveChangesAsync();
            return new like { Number= b.piaoshu };

        }
        [Route("api/uoload/")]
        [HttpPost]
        public async Task<IActionResult> UploadAsync([FromBody] string file)
        {
            if (file == null || file.Length == 0)
                return Content("file not selected");

            var path = System.IO.Path.Combine(
                        Directory.GetCurrentDirectory(),
                        "image.jpg");

            using (var stream = new FileStream(path, FileMode.Create))
            {
                await stream.WriteAsync(Convert.FromBase64String(file));
            }

            return Ok();
        }


        public class like
        {
            public int Number { get; set; } 
        }

        [Route("api/updateform/")]
        [HttpPost]
        public async Task<string> PostAsync([FromBody] form_get for1)
        {

                form form1 = new form();
                form1.team_name = for1.team_name;
                form1.team_password = for1.team_password;
                form1.team_tel = for1.team_tel;
                List<role> role = for1.role_get;
                form1.role = role;
                TestDbContext ctx = new TestDbContext();
                ctx.Forms.Add(form1);
                await ctx.SaveChangesAsync();

                try
                {


                }
                catch
                {

                    return "��Ϣ������";
                }





                try
                {
                    //  Base64ToImage(for1.loge_base64, AppDomain.CurrentDomain.BaseDirectory, for1.team_name);
                }
                catch
                {

                }

                JObject postedJObject = new JObject();
                postedJObject.Add("msg", "�ɹ�");
                //   System.IO.File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + "/allteam.txt", for1.team_name);
                try
                {
                    await MessageManager.SendGroupMessageAsync("456414070", for1.team_name + "�ѳɹ�����");
                    String paramString = postedJObject.ToString(Newtonsoft.Json.Formatting.None, null);
                }
                catch
                {

                }

                return "ok";

        }


        public string Base64ToImage(string base64Str, string path, string imgName)
        {
            string filename = "";//����һ��string���͵����·��
            //ȡͼƬ�ĺ�׺��ʽ
            string hz = base64Str.Split(',')[0].Split(';')[0].Split('/')[1];
            string[] str = base64Str.Split(',');  //base64StrΪbase64�������ַ������ȴ���һ�µõ���������Ҫ���ַ���
            byte[] imageBytes = Convert.FromBase64String(str[1]);
            //����MemoryStream����
            MemoryStream memoryStream = new MemoryStream(imageBytes, 0, imageBytes.Length);
            memoryStream.Write(imageBytes, 0, imageBytes.Length);
            filename = path + imgName + "." + hz;//��Ҫ��������·��������
    
            string imagesurl2 = path + imgName + "." + hz; //ת���ɾ���·�� 
            //  ת��ͼƬ
            Image image = Image.FromStream(memoryStream);
            //   ͼƬ����
            string iname = DateTime.Now.ToString("yyMMddhhmmss");
            image.Save(imagesurl2);  // ��ͼƬ�浽����Server.MapPath("pic\\") + iname + "." + hz
            return filename;
        }
        [Route("api/addbot/")]
        [HttpPost]
        public async Task<ActionResult<string>> AddbotAsync(string qq,string adress,string key)
        {
            bot.QQ = qq;
            bot.Address = adress;
            bot.VerifyKey = key;
            await bot.LaunchAsync();

            bot.MessageReceived
    .OfType<GroupMessageReceiver>()
    .Subscribe(async x =>
    {
        if( x.MessageChain.GetPlainMessage()=="���ж���")
        {

            string[] names = null;
            names = System.IO.File.ReadAllLines(AppDomain.CurrentDomain.BaseDirectory + "/allteam.txt");

            string res = string.Join("\r\n", names);
            await MessageManager.SendGroupMessageAsync(x.Sender.Group, "���¶����ѱ�����\r\n"+res);
        }
        if (x.MessageChain.GetPlainMessage().Contains("ͶƱ#")) 
                {
            string msg=x.MessageChain.GetPlainMessage();
            INIFile ini = new INIFile(AppDomain.CurrentDomain.BaseDirectory + "team.ini");
            string name = msg.Split("#")[1];
            string timer=ini.IniReadValue(name, "timer");
            await MessageManager.SendGroupMessageAsync(x.Sender.Group, name);
            if (timer!="")
            {
               int number= ini.IniReadValue(name, "number").ToInt32();
                number++;
                ini.IniWriteValue(name, "number", number.ToString());
                await MessageManager.SendGroupMessageAsync(x.Sender.Group, "ͶƱ�ɹ���\r\nƱ����" + number);
            }
            else
            {
                await MessageManager.SendGroupMessageAsync(x.Sender.Group, "ͶƱʧ��,�޴˶��飺" + name);

            }
        }

    });
            return "ok";
        }

        MiraiBot bot = new MiraiBot
        {
            Address = "localhost:8080",
            QQ = "1590454991",
            VerifyKey = "1145141919810"
        };








    }



    public class role
    {
        public long Id { get; set; }
        public form form { get; set; }//�����ĸ�����
        public string role_id{ get; set; } = "��";
        public string role_name { get; set; } = "��";//����
                              public string role_lin { get; set; } }

    public class role_get
    {
        public string role_id { get; set; } = "��";
        public string role_name { get; set; } = "��";//����
        public string role_lin { get; set; } = "��";
    }
    public class form {
        public long Id { get; set; }
        public int piaoshu { get; set; }
        public DateTime time { get; set; }= DateTime.Now;
        public string team_name { get; set; } public string team_password { get; set; } public string team_tel { get; set; } public List<role> role { get; set; } }

    public class form_get
    {
        public int piaoshu { get; set; }
        public DateTime time { get; set; } = DateTime.Now;
        public string team_name { get; set; }
        public string team_password { get; set; }
        public string team_tel { get; set; }
        public List<role> role_get { get; set; }
    }




    public class form1
        {

        public long Id { get; set; }
        public string team_name { get; set; }
            public string team_password { get; set; }
        public string team_tel { get; set; }


        public role[] role1 { get; set; }

    public string loge_base64 { get; set; } = "null";
    }

}






[Route("api/allteam/")]
public class ���ж��� : ControllerBase
{
    private static readonly string[] Summaries = new[]
    {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

    [HttpGet]
    public List<team> Get()
    {
          TestDbContext ctx= new TestDbContext();
        List<team> teams= new List<team>();
        int a = 0;
        foreach (form for1 in ctx.Forms)
        {
            teams.Add( new team { name = for1.team_name, timer = for1.time, piaoshu = for1.piaoshu });
            a++;
        }
        return teams;

    }



    public struct team
    {
        public string name { get; set; }
        public DateTime timer { get; set; }

        public int piaoshu { get; set; }
    }









    [Route("api/getform/")]
    public class ��ñ��� : ControllerBase
    {

        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        [HttpPost,]
        public ActionResult<string> Get()
        {
            /*
           string[] names = null;
           INIFile ini = new INIFile(AppDomain.CurrentDomain.BaseDirectory + "team.ini");
           names = System.IO.File.ReadAllLines(AppDomain.CurrentDomain.BaseDirectory + "/allteam.txt");
           var workbook = new WorkBook();
           var sheet = workbook.NewSheet("sheet1");
           form_uri role=null;
           role.uri = "sjkdsj";
           try
           {
               foreach (string team in names)
               {
                   ini.IniReadValue(team, "�ʾ�����"); // дֵ
                   ini.IniReadValue(team, "������1id");
                   ini.IniReadValue(team, "������2id");
                   ini.IniReadValue(team, "������3id");
                   ini.IniReadValue(team, "������4id");
                   ini.IniReadValue(team, "������5id");


                   //    ini.IniWriteValue(for1.team_name, "ip", for1.ip);


                   ini.IniReadValue(team, "������1name");
                   ini.IniReadValue(team, "������2name");
                   ini.IniReadValue(team, "������3name");
                   ini.IniReadValue(team, "������4name");
                   ini.IniReadValue(team, "������5name");

                   ini.IniReadValue(team, "������1lin");
                   ini.IniReadValue(team, "������2lin");
                   ini.IniReadValue(team, "������3lin");
                   ini.IniReadValue(team, "������4lin");
                   ini.IniReadValue(team, "������5lin");
               }
           }
           catch
           {

           }
           try
           {

               ini.IniWriteValue(for1.team_name, "������6name", for1.role[5].role_name);
               ini.IniWriteValue(for1.team_name, "������7name", for1.role[6].role_name);
               ini.IniWriteValue(for1.team_name, "������6lin", for1.role[5].role_lin);
               ini.IniWriteValue(for1.team_name, "������7lin", for1.role[6].role_lin);
               ini.IniWriteValue(for1.team_name, "������6id", for1.role[5].role_id);
               ini.IniWriteValue(for1.team_name, "������7id", for1.role[6].role_id);
               ini.IniWriteValue(for1.team_name, "timer", DateTime.Now.ToString());

           }
           catch
           {

           }

              ;
       } */ return "1111";
        }

        public class form_uri
        {
            public string uri { get; set; }
        }



    }
}











    





